package com.codejudge.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Submission entity representing a user's code submission for a problem.
 */
@Entity
@Table(name = "submissions")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Submission {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "problem_id", nullable = false)
    private Problem problem;
    
    @NotBlank(message = "Source code is required")
    @Column(columnDefinition = "TEXT", nullable = false)
    private String sourceCode;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "programming_language", nullable = false)
    private ProgrammingLanguage programmingLanguage = ProgrammingLanguage.JAVA;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private SubmissionStatus status = SubmissionStatus.PENDING;
    
    @Column(name = "execution_time")
    private Long executionTime; // milliseconds
    
    @Column(name = "memory_used")
    private Long memoryUsed; // KB
    
    @Column(name = "score")
    private Integer score;
    
    @Column(name = "total_test_cases")
    private Integer totalTestCases;
    
    @Column(name = "passed_test_cases")
    private Integer passedTestCases;
    
    @Column(columnDefinition = "TEXT")
    private String errorMessage;
    
    @Column(name = "compilation_error")
    private Boolean compilationError = false;
    
    @Column(name = "runtime_error")
    private Boolean runtimeError = false;
    
    @Column(name = "time_limit_exceeded")
    private Boolean timeLimitExceeded = false;
    
    @Column(name = "memory_limit_exceeded")
    private Boolean memoryLimitExceeded = false;
    
    @Column(name = "submitted_at", nullable = false)
    private LocalDateTime submittedAt;
    
    @Column(name = "evaluated_at")
    private LocalDateTime evaluatedAt;
    
    @OneToMany(mappedBy = "submission", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<TestResult> testResults;
    
    @PrePersist
    protected void onCreate() {
        submittedAt = LocalDateTime.now();
    }
    
    /**
     * Calculate the success rate for this submission
     */
    public double getSuccessRate() {
        if (totalTestCases == null || totalTestCases == 0) {
            return 0.0;
        }
        return (double) passedTestCases / totalTestCases * 100;
    }
    
    /**
     * Check if submission was successful
     */
    public boolean isSuccessful() {
        return status == SubmissionStatus.ACCEPTED;
    }
    
    /**
     * Programming languages supported by the platform
     */
    public enum ProgrammingLanguage {
        JAVA("java"),
        PYTHON("py"),
        CPP("cpp"),
        C("c"),
        JAVASCRIPT("js");
        
        private final String extension;
        
        ProgrammingLanguage(String extension) {
            this.extension = extension;
        }
        
        public String getExtension() {
            return extension;
        }
    }
    
    /**
     * Submission status enumeration
     */
    public enum SubmissionStatus {
        PENDING("Pending"),
        COMPILING("Compiling"),
        RUNNING("Running"),
        ACCEPTED("Accepted"),
        WRONG_ANSWER("Wrong Answer"),
        COMPILATION_ERROR("Compilation Error"),
        RUNTIME_ERROR("Runtime Error"),
        TIME_LIMIT_EXCEEDED("Time Limit Exceeded"),
        MEMORY_LIMIT_EXCEEDED("Memory Limit Exceeded"),
        SYSTEM_ERROR("System Error");
        
        private final String displayName;
        
        SubmissionStatus(String displayName) {
            this.displayName = displayName;
        }
        
        public String getDisplayName() {
            return displayName;
        }
    }
} 