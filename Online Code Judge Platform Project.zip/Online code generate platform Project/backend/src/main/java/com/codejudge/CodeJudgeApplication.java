package com.codejudge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Main application class for the Online Code Judge Platform.
 * 
 * This Spring Boot application provides:
 * - User authentication and authorization
 * - Problem management and submission handling
 * - Code execution engine with Docker sandboxing
 * - Real-time results and leaderboards
 * - RESTful API endpoints
 * 
 * @author Code Judge Team
 * @version 1.0.0
 */
@SpringBootApplication
@EnableAsync
@EnableScheduling
public class CodeJudgeApplication {

    public static void main(String[] args) {
        SpringApplication.run(CodeJudgeApplication.class, args);
        System.out.println("🚀 Online Code Judge Platform started successfully!");
        System.out.println("📊 Application is running on: http://localhost:8080");
        System.out.println("📚 API Documentation: http://localhost:8080/swagger-ui.html");
    }
} 