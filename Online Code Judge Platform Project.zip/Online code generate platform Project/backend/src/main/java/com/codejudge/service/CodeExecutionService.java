package com.codejudge.service;

import com.codejudge.entity.Submission;
import com.codejudge.entity.TestCase;
import com.codejudge.entity.TestResult;
import com.github.dockerjava.api.DockerClient;
import com.github.dockerjava.api.command.CreateContainerResponse;
import com.github.dockerjava.api.command.ExecCreateCmdResponse;
import com.github.dockerjava.api.model.Bind;
import com.github.dockerjava.api.model.HostConfig;
import com.github.dockerjava.api.model.Volume;
import com.github.dockerjava.core.DefaultDockerClientConfig;
import com.github.dockerjava.core.DockerClientBuilder;
import com.github.dockerjava.core.DockerClientConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

/**
 * Service responsible for executing code submissions in a safe sandboxed environment.
 * Uses Docker containers to isolate code execution and prevent security issues.
 */
@Service
@Slf4j
public class CodeExecutionService {
    
    @Value("${code.execution.docker.image:openjdk:17-jdk-slim}")
    private String dockerImage;
    
    @Value("${code.execution.timeout:30}")
    private int executionTimeoutSeconds;
    
    @Value("${code.execution.memory.limit:512m}")
    private String memoryLimit;
    
    @Value("${code.execution.workspace:/tmp/code-execution}")
    private String workspacePath;
    
    private final DockerClient dockerClient;
    
    public CodeExecutionService() {
        DockerClientConfig config = DefaultDockerClientConfig.createDefaultConfigBuilder()
                .withDockerHost("unix:///var/run/docker.sock")
                .build();
        this.dockerClient = DockerClientBuilder.getInstance(config).build();
    }
    
    /**
     * Execute a submission against all test cases for a problem
     */
    public CompletableFuture<Submission> executeSubmission(Submission submission) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                log.info("Starting execution for submission ID: {}", submission.getId());
                
                // Create temporary workspace
                String workspaceId = UUID.randomUUID().toString();
                Path workspace = createWorkspace(workspaceId);
                
                // Write source code to file
                String sourceFileName = "Solution." + submission.getProgrammingLanguage().getExtension();
                Path sourceFile = writeSourceCode(workspace, sourceFileName, submission.getSourceCode());
                
                // Compile the code
                if (!compileCode(workspace, sourceFileName)) {
                    submission.setStatus(Submission.SubmissionStatus.COMPILATION_ERROR);
                    submission.setErrorMessage("Compilation failed");
                    return submission;
                }
                
                // Execute against test cases
                executeTestCases(submission, workspace);
                
                // Clean up workspace
                cleanupWorkspace(workspace);
                
                log.info("Execution completed for submission ID: {}", submission.getId());
                return submission;
                
            } catch (Exception e) {
                log.error("Error executing submission ID: {}", submission.getId(), e);
                submission.setStatus(Submission.SubmissionStatus.SYSTEM_ERROR);
                submission.setErrorMessage("System error: " + e.getMessage());
                return submission;
            }
        });
    }
    
    /**
     * Create a temporary workspace for code execution
     */
    private Path createWorkspace(String workspaceId) throws IOException {
        Path workspace = Paths.get(workspacePath, workspaceId);
        Files.createDirectories(workspace);
        return workspace;
    }
    
    /**
     * Write source code to a file in the workspace
     */
    private Path writeSourceCode(Path workspace, String fileName, String sourceCode) throws IOException {
        Path sourceFile = workspace.resolve(fileName);
        Files.write(sourceFile, sourceCode.getBytes());
        return sourceFile;
    }
    
    /**
     * Compile Java code using Docker container
     */
    private boolean compileCode(Path workspace, String sourceFileName) {
        try {
            String containerId = createCompilationContainer(workspace);
            
            // Execute compilation command
            String[] compileCommand = {"javac", sourceFileName};
            ExecCreateCmdResponse execResponse = dockerClient.execCreateCmd(containerId)
                    .withCmd(compileCommand)
                    .withAttachStdout(true)
                    .withAttachStderr(true)
                    .exec();
            
            // Execute and get output
            try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
                dockerClient.execStartCmd(execResponse.getId()).exec(
                        new com.github.dockerjava.core.command.ExecStartResultCallback(outputStream, outputStream)
                ).awaitCompletion(executionTimeoutSeconds, TimeUnit.SECONDS);
                
                int exitCode = dockerClient.inspectExecCmd(execResponse.getId()).exec().getExitCode();
                
                // Clean up container
                dockerClient.removeContainerCmd(containerId).exec();
                
                return exitCode == 0;
            }
            
        } catch (Exception e) {
            log.error("Error during compilation", e);
            return false;
        }
    }
    
    /**
     * Execute code against all test cases
     */
    private void executeTestCases(Submission submission, Path workspace) {
        int totalTestCases = submission.getProblem().getTestCases().size();
        int passedTestCases = 0;
        
        submission.setTotalTestCases(totalTestCases);
        submission.setStatus(Submission.SubmissionStatus.RUNNING);
        
        for (TestCase testCase : submission.getProblem().getTestCases()) {
            TestResult testResult = executeTestCase(submission, testCase, workspace);
            
            if (testResult.getStatus() == TestResult.TestResultStatus.PASSED) {
                passedTestCases++;
            }
            
            // Update submission based on test result
            updateSubmissionFromTestResult(submission, testResult);
        }
        
        submission.setPassedTestCases(passedTestCases);
        submission.setEvaluatedAt(java.time.LocalDateTime.now());
        
        // Calculate final score
        if (passedTestCases == totalTestCases) {
            submission.setStatus(Submission.SubmissionStatus.ACCEPTED);
            submission.setScore(submission.getProblem().getMaxScore());
        } else {
            submission.setStatus(Submission.SubmissionStatus.WRONG_ANSWER);
            submission.setScore((int) ((double) passedTestCases / totalTestCases * submission.getProblem().getMaxScore()));
        }
    }
    
    /**
     * Execute a single test case
     */
    private TestResult executeTestCase(Submission submission, TestCase testCase, Path workspace) {
        TestResult testResult = new TestResult();
        testResult.setSubmission(submission);
        testResult.setTestCase(testCase);
        testResult.setExpectedOutput(testCase.getExpectedOutput());
        
        try {
            String containerId = createExecutionContainer(workspace, testCase);
            
            // Execute the program with test case input
            String[] runCommand = {"java", "Solution"};
            ExecCreateCmdResponse execResponse = dockerClient.execCreateCmd(containerId)
                    .withCmd(runCommand)
                    .withAttachStdout(true)
                    .withAttachStderr(true)
                    .exec();
            
            // Execute with input
            try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                 ByteArrayInputStream inputStream = new ByteArrayInputStream(testCase.getInput().getBytes())) {
                
                long startTime = System.currentTimeMillis();
                
                dockerClient.execStartCmd(execResponse.getId())
                        .withStdIn(inputStream)
                        .exec(new com.github.dockerjava.core.command.ExecStartResultCallback(outputStream, outputStream))
                        .awaitCompletion(testCase.getEffectiveTimeLimit(), TimeUnit.MILLISECONDS);
                
                long endTime = System.currentTimeMillis();
                long executionTime = endTime - startTime;
                
                int exitCode = dockerClient.inspectExecCmd(execResponse.getId()).exec().getExitCode();
                String output = outputStream.toString().trim();
                
                // Clean up container
                dockerClient.removeContainerCmd(containerId).exec();
                
                // Process result
                processTestResult(testResult, exitCode, output, executionTime, testCase);
                
            }
            
        } catch (Exception e) {
            log.error("Error executing test case", e);
            testResult.setStatus(TestResult.TestResultStatus.SYSTEM_ERROR);
            testResult.setErrorMessage("System error: " + e.getMessage());
        }
        
        return testResult;
    }
    
    /**
     * Create a Docker container for compilation
     */
    private String createCompilationContainer(Path workspace) {
        HostConfig hostConfig = new HostConfig()
                .withBinds(new Bind(workspace.toString(), new Volume("/workspace")))
                .withMemory(Long.parseLong(memoryLimit.replace("m", "")) * 1024 * 1024L)
                .withCpuCount(1L)
                .withNetworkMode("none");
        
        CreateContainerResponse container = dockerClient.createContainerCmd(dockerImage)
                .withWorkingDir("/workspace")
                .withHostConfig(hostConfig)
                .withCmd("sleep", "300")
                .exec();
        
        dockerClient.startContainerCmd(container.getId()).exec();
        return container.getId();
    }
    
    /**
     * Create a Docker container for code execution
     */
    private String createExecutionContainer(Path workspace, TestCase testCase) {
        HostConfig hostConfig = new HostConfig()
                .withBinds(new Bind(workspace.toString(), new Volume("/workspace")))
                .withMemory(Long.parseLong(memoryLimit.replace("m", "")) * 1024 * 1024L)
                .withCpuCount(1L)
                .withNetworkMode("none")
                .withReadonlyRootfs(true);
        
        CreateContainerResponse container = dockerClient.createContainerCmd(dockerImage)
                .withWorkingDir("/workspace")
                .withHostConfig(hostConfig)
                .withCmd("sleep", "300")
                .exec();
        
        dockerClient.startContainerCmd(container.getId()).exec();
        return container.getId();
    }
    
    /**
     * Process the result of a test case execution
     */
    private void processTestResult(TestResult testResult, int exitCode, String output, 
                                 long executionTime, TestCase testCase) {
        testResult.setActualOutput(output);
        testResult.setExecutionTime(executionTime);
        
        if (exitCode != 0) {
            testResult.setStatus(TestResult.TestResultStatus.RUNTIME_ERROR);
            testResult.setErrorMessage("Program exited with code: " + exitCode);
            return;
        }
        
        if (executionTime > testCase.getEffectiveTimeLimit()) {
            testResult.setStatus(TestResult.TestResultStatus.TIME_LIMIT_EXCEEDED);
            testResult.setErrorMessage("Time limit exceeded");
            return;
        }
        
        // Compare output
        if (output.equals(testCase.getExpectedOutput().trim())) {
            testResult.setStatus(TestResult.TestResultStatus.PASSED);
            testResult.setIsCorrect(true);
        } else {
            testResult.setStatus(TestResult.TestResultStatus.FAILED);
            testResult.setIsCorrect(false);
        }
    }
    
    /**
     * Update submission status based on test result
     */
    private void updateSubmissionFromTestResult(Submission submission, TestResult testResult) {
        switch (testResult.getStatus()) {
            case RUNTIME_ERROR:
                submission.setRuntimeError(true);
                break;
            case TIME_LIMIT_EXCEEDED:
                submission.setTimeLimitExceeded(true);
                break;
            case MEMORY_LIMIT_EXCEEDED:
                submission.setMemoryLimitExceeded(true);
                break;
        }
        
        // Update execution time and memory usage
        if (testResult.getExecutionTime() != null) {
            if (submission.getExecutionTime() == null || 
                testResult.getExecutionTime() > submission.getExecutionTime()) {
                submission.setExecutionTime(testResult.getExecutionTime());
            }
        }
    }
    
    /**
     * Clean up the workspace
     */
    private void cleanupWorkspace(Path workspace) {
        try {
            Files.walk(workspace)
                    .sorted((a, b) -> b.compareTo(a))
                    .forEach(path -> {
                        try {
                            Files.delete(path);
                        } catch (IOException e) {
                            log.warn("Could not delete file: {}", path, e);
                        }
                    });
        } catch (IOException e) {
            log.warn("Error cleaning up workspace: {}", workspace, e);
        }
    }
} 