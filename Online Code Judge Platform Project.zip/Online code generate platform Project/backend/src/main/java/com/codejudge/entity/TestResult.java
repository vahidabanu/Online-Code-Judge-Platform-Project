package com.codejudge.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalDateTime;

/**
 * TestResult entity representing the result of a single test case execution.
 */
@Entity
@Table(name = "test_results")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TestResult {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "submission_id", nullable = false)
    private Submission submission;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "test_case_id", nullable = false)
    private TestCase testCase;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private TestResultStatus status = TestResultStatus.PENDING;
    
    @Column(name = "actual_output", columnDefinition = "TEXT")
    private String actualOutput;
    
    @Column(name = "expected_output", columnDefinition = "TEXT")
    private String expectedOutput;
    
    @Column(name = "execution_time")
    private Long executionTime; // milliseconds
    
    @Column(name = "memory_used")
    private Long memoryUsed; // KB
    
    @Column(columnDefinition = "TEXT")
    private String errorMessage;
    
    @Column(name = "is_correct", nullable = false)
    private Boolean isCorrect = false;
    
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
    
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }
    
    /**
     * Test result status enumeration
     */
    public enum TestResultStatus {
        PENDING("Pending"),
        PASSED("Passed"),
        FAILED("Failed"),
        COMPILATION_ERROR("Compilation Error"),
        RUNTIME_ERROR("Runtime Error"),
        TIME_LIMIT_EXCEEDED("Time Limit Exceeded"),
        MEMORY_LIMIT_EXCEEDED("Memory Limit Exceeded"),
        SYSTEM_ERROR("System Error");
        
        private final String displayName;
        
        TestResultStatus(String displayName) {
            this.displayName = displayName;
        }
        
        public String getDisplayName() {
            return displayName;
        }
    }
} 