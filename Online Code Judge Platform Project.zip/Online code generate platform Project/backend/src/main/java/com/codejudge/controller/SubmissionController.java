package com.codejudge.controller;

import com.codejudge.dto.SubmissionRequest;
import com.codejudge.dto.SubmissionResponse;
import com.codejudge.entity.Submission;
import com.codejudge.service.SubmissionService;
import com.codejudge.service.CodeExecutionService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

/**
 * REST controller for submission management and code execution.
 */
@RestController
@RequestMapping("/api/submissions")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class SubmissionController {
    
    private final SubmissionService submissionService;
    private final CodeExecutionService codeExecutionService;
    
    /**
     * Submit code for a problem
     */
    @PostMapping
    public ResponseEntity<?> submitCode(
            Authentication authentication,
            @Valid @RequestBody SubmissionRequest request) {
        try {
            // Create submission
            Submission submission = submissionService.createSubmission(authentication.getName(), request);
            
            // Execute code asynchronously
            CompletableFuture<Submission> executionFuture = codeExecutionService.executeSubmission(submission);
            
            // Return immediate response with submission ID
            Map<String, Object> response = new HashMap<>();
            response.put("message", "Submission received and queued for execution");
            response.put("submissionId", submission.getId());
            response.put("status", submission.getStatus().getDisplayName());
            
            // Execute in background and update submission
            executionFuture.thenAccept(executedSubmission -> {
                submissionService.updateSubmission(executedSubmission);
            });
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    /**
     * Get submission status and results
     */
    @GetMapping("/{id}")
    public ResponseEntity<SubmissionResponse> getSubmission(@PathVariable Long id) {
        SubmissionResponse submission = submissionService.getSubmissionById(id);
        return ResponseEntity.ok(submission);
    }
    
    /**
     * Get user's submissions
     */
    @GetMapping("/user")
    public ResponseEntity<Page<SubmissionResponse>> getUserSubmissions(
            Authentication authentication,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        Page<SubmissionResponse> submissions = submissionService.getUserSubmissions(
                authentication.getName(), pageable);
        return ResponseEntity.ok(submissions);
    }
    
    /**
     * Get submissions for a specific problem
     */
    @GetMapping("/problem/{problemId}")
    public ResponseEntity<Page<SubmissionResponse>> getProblemSubmissions(
            @PathVariable Long problemId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        Page<SubmissionResponse> submissions = submissionService.getProblemSubmissions(problemId, pageable);
        return ResponseEntity.ok(submissions);
    }
    
    /**
     * Get all submissions (Admin/Teacher only)
     */
    @GetMapping
    public ResponseEntity<Page<SubmissionResponse>> getAllSubmissions(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String language) {
        
        Pageable pageable = PageRequest.of(page, size);
        Page<SubmissionResponse> submissions = submissionService.getAllSubmissions(pageable, status, language);
        return ResponseEntity.ok(submissions);
    }
    
    /**
     * Get submission statistics
     */
    @GetMapping("/stats")
    public ResponseEntity<?> getSubmissionStats(Authentication authentication) {
        Map<String, Object> stats = submissionService.getSubmissionStats(authentication.getName());
        return ResponseEntity.ok(stats);
    }
    
    /**
     * Get recent submissions
     */
    @GetMapping("/recent")
    public ResponseEntity<?> getRecentSubmissions(@RequestParam(defaultValue = "10") int limit) {
        return ResponseEntity.ok(submissionService.getRecentSubmissions(limit));
    }
    
    /**
     * Re-run a submission (Admin/Teacher only)
     */
    @PostMapping("/{id}/rerun")
    public ResponseEntity<?> rerunSubmission(@PathVariable Long id) {
        try {
            Submission submission = submissionService.getSubmissionEntityById(id);
            
            // Reset submission status
            submission.setStatus(Submission.SubmissionStatus.PENDING);
            submission.setErrorMessage(null);
            submission.setScore(null);
            submission.setExecutionTime(null);
            submission.setMemoryUsed(null);
            submission.setTotalTestCases(null);
            submission.setPassedTestCases(null);
            
            // Re-execute
            CompletableFuture<Submission> executionFuture = codeExecutionService.executeSubmission(submission);
            
            Map<String, Object> response = new HashMap<>();
            response.put("message", "Submission re-execution started");
            response.put("submissionId", submission.getId());
            
            // Execute in background and update submission
            executionFuture.thenAccept(executedSubmission -> {
                submissionService.updateSubmission(executedSubmission);
            });
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    /**
     * Get submission test results
     */
    @GetMapping("/{id}/test-results")
    public ResponseEntity<?> getSubmissionTestResults(@PathVariable Long id) {
        return ResponseEntity.ok(submissionService.getSubmissionTestResults(id));
    }
    
    /**
     * Get user's best submission for a problem
     */
    @GetMapping("/user/{userId}/problem/{problemId}/best")
    public ResponseEntity<SubmissionResponse> getUserBestSubmission(
            @PathVariable Long userId,
            @PathVariable Long problemId) {
        SubmissionResponse submission = submissionService.getUserBestSubmission(userId, problemId);
        return ResponseEntity.ok(submission);
    }
} 