package com.codejudge.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalDateTime;

/**
 * TestCase entity representing test cases for coding problems.
 */
@Entity
@Table(name = "test_cases")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TestCase {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "problem_id", nullable = false)
    private Problem problem;
    
    @NotBlank(message = "Input is required")
    @Column(columnDefinition = "TEXT", nullable = false)
    private String input;
    
    @NotBlank(message = "Expected output is required")
    @Column(columnDefinition = "TEXT", nullable = false)
    private String expectedOutput;
    
    @Column(name = "test_case_number", nullable = false)
    private Integer testCaseNumber;
    
    @Column(name = "is_sample", nullable = false)
    private Boolean isSample = false;
    
    @Column(name = "is_hidden", nullable = false)
    private Boolean isHidden = false;
    
    @Column(name = "time_limit")
    private Integer timeLimit; // Override problem time limit if specified
    
    @Column(name = "memory_limit")
    private Integer memoryLimit; // Override problem memory limit if specified
    
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
    
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }
    
    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
    
    /**
     * Get the effective time limit for this test case
     */
    public Integer getEffectiveTimeLimit() {
        return timeLimit != null ? timeLimit : problem.getTimeLimit();
    }
    
    /**
     * Get the effective memory limit for this test case
     */
    public Integer getEffectiveMemoryLimit() {
        return memoryLimit != null ? memoryLimit : problem.getMemoryLimit();
    }
} 