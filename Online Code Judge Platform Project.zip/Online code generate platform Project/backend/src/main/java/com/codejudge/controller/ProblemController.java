package com.codejudge.controller;

import com.codejudge.dto.ProblemCreateRequest;
import com.codejudge.dto.ProblemResponse;
import com.codejudge.entity.Problem;
import com.codejudge.service.ProblemService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * REST controller for problem management operations.
 */
@RestController
@RequestMapping("/api/problems")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class ProblemController {
    
    private final ProblemService problemService;
    
    /**
     * Get all problems with pagination and filtering
     */
    @GetMapping
    public ResponseEntity<Page<ProblemResponse>> getProblems(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String difficulty,
            @RequestParam(required = false) String search) {
        
        Pageable pageable = PageRequest.of(page, size);
        Page<ProblemResponse> problems = problemService.getProblems(pageable, difficulty, search);
        return ResponseEntity.ok(problems);
    }
    
    /**
     * Get a specific problem by ID
     */
    @GetMapping("/{id}")
    public ResponseEntity<ProblemResponse> getProblem(@PathVariable Long id) {
        ProblemResponse problem = problemService.getProblemById(id);
        return ResponseEntity.ok(problem);
    }
    
    /**
     * Create a new problem (Admin/Teacher only)
     */
    @PostMapping
    @PreAuthorize("hasRole('ADMIN') or hasRole('TEACHER')")
    public ResponseEntity<?> createProblem(@Valid @RequestBody ProblemCreateRequest request) {
        try {
            ProblemResponse problem = problemService.createProblem(request);
            Map<String, Object> response = new HashMap<>();
            response.put("message", "Problem created successfully");
            response.put("problem", problem);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    /**
     * Update an existing problem (Admin/Teacher only)
     */
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('TEACHER')")
    public ResponseEntity<?> updateProblem(
            @PathVariable Long id,
            @Valid @RequestBody ProblemCreateRequest request) {
        try {
            ProblemResponse problem = problemService.updateProblem(id, request);
            Map<String, Object> response = new HashMap<>();
            response.put("message", "Problem updated successfully");
            response.put("problem", problem);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    /**
     * Delete a problem (Admin only)
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> deleteProblem(@PathVariable Long id) {
        try {
            problemService.deleteProblem(id);
            Map<String, String> response = new HashMap<>();
            response.put("message", "Problem deleted successfully");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    /**
     * Get problem statistics
     */
    @GetMapping("/{id}/stats")
    public ResponseEntity<?> getProblemStats(@PathVariable Long id) {
        Map<String, Object> stats = problemService.getProblemStats(id);
        return ResponseEntity.ok(stats);
    }
    
    /**
     * Get problems by difficulty
     */
    @GetMapping("/difficulty/{difficulty}")
    public ResponseEntity<Page<ProblemResponse>> getProblemsByDifficulty(
            @PathVariable String difficulty,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        Page<ProblemResponse> problems = problemService.getProblemsByDifficulty(difficulty, pageable);
        return ResponseEntity.ok(problems);
    }
    
    /**
     * Search problems by title or description
     */
    @GetMapping("/search")
    public ResponseEntity<Page<ProblemResponse>> searchProblems(
            @RequestParam String query,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        Page<ProblemResponse> problems = problemService.searchProblems(query, pageable);
        return ResponseEntity.ok(problems);
    }
    
    /**
     * Get recent problems
     */
    @GetMapping("/recent")
    public ResponseEntity<?> getRecentProblems(@RequestParam(defaultValue = "5") int limit) {
        return ResponseEntity.ok(problemService.getRecentProblems(limit));
    }
    
    /**
     * Get popular problems (most submissions)
     */
    @GetMapping("/popular")
    public ResponseEntity<?> getPopularProblems(@RequestParam(defaultValue = "10") int limit) {
        return ResponseEntity.ok(problemService.getPopularProblems(limit));
    }
} 