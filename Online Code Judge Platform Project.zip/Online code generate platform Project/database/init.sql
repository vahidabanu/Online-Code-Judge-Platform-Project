-- Online Code Judge Platform Database Initialization
-- This script creates the database schema and inserts sample data

USE codejudge;

-- Create tables (if not exists - JPA will handle this, but we include for reference)
-- Users table
CREATE TABLE IF NOT EXISTS users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    role ENUM('STUDENT', 'TEACHER', 'ADMIN') DEFAULT 'STUDENT',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL,
    is_active BOOLEAN DEFAULT TRUE,
    total_submissions INT DEFAULT 0,
    successful_submissions INT DEFAULT 0,
    total_score INT DEFAULT 0
);

-- Problems table
CREATE TABLE IF NOT EXISTS problems (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    problem_statement TEXT,
    input_format TEXT,
    output_format TEXT,
    constraints TEXT,
    sample_input TEXT,
    sample_output TEXT,
    explanation TEXT,
    difficulty ENUM('EASY', 'MEDIUM', 'HARD', 'EXPERT') DEFAULT 'EASY',
    time_limit INT DEFAULT 1000,
    memory_limit INT DEFAULT 256,
    max_score INT DEFAULT 100,
    total_submissions INT DEFAULT 0,
    successful_submissions INT DEFAULT 0,
    created_by BIGINT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Test cases table
CREATE TABLE IF NOT EXISTS test_cases (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    problem_id BIGINT NOT NULL,
    input TEXT NOT NULL,
    expected_output TEXT NOT NULL,
    test_case_number INT NOT NULL,
    is_sample BOOLEAN DEFAULT FALSE,
    is_hidden BOOLEAN DEFAULT FALSE,
    time_limit INT,
    memory_limit INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (problem_id) REFERENCES problems(id) ON DELETE CASCADE
);

-- Submissions table
CREATE TABLE IF NOT EXISTS submissions (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    problem_id BIGINT NOT NULL,
    source_code TEXT NOT NULL,
    programming_language ENUM('JAVA', 'PYTHON', 'CPP', 'C', 'JAVASCRIPT') DEFAULT 'JAVA',
    status ENUM('PENDING', 'COMPILING', 'RUNNING', 'ACCEPTED', 'WRONG_ANSWER', 'COMPILATION_ERROR', 'RUNTIME_ERROR', 'TIME_LIMIT_EXCEEDED', 'MEMORY_LIMIT_EXCEEDED', 'SYSTEM_ERROR') DEFAULT 'PENDING',
    execution_time BIGINT,
    memory_used BIGINT,
    score INT,
    total_test_cases INT,
    passed_test_cases INT,
    error_message TEXT,
    compilation_error BOOLEAN DEFAULT FALSE,
    runtime_error BOOLEAN DEFAULT FALSE,
    time_limit_exceeded BOOLEAN DEFAULT FALSE,
    memory_limit_exceeded BOOLEAN DEFAULT FALSE,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    evaluated_at TIMESTAMP NULL,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (problem_id) REFERENCES problems(id)
);

-- Test results table
CREATE TABLE IF NOT EXISTS test_results (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    submission_id BIGINT NOT NULL,
    test_case_id BIGINT NOT NULL,
    status ENUM('PENDING', 'PASSED', 'FAILED', 'COMPILATION_ERROR', 'RUNTIME_ERROR', 'TIME_LIMIT_EXCEEDED', 'MEMORY_LIMIT_EXCEEDED', 'SYSTEM_ERROR') DEFAULT 'PENDING',
    actual_output TEXT,
    expected_output TEXT,
    execution_time BIGINT,
    memory_used BIGINT,
    error_message TEXT,
    is_correct BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (submission_id) REFERENCES submissions(id) ON DELETE CASCADE,
    FOREIGN KEY (test_case_id) REFERENCES test_cases(id)
);

-- Insert sample admin user
INSERT INTO users (username, email, password, first_name, last_name, role) VALUES
('admin', 'admin@codejudge.com', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVEFDa', 'Admin', 'User', 'ADMIN')
ON DUPLICATE KEY UPDATE username=username;

-- Insert sample teacher user
INSERT INTO users (username, email, password, first_name, last_name, role) VALUES
('teacher', 'teacher@codejudge.com', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVEFDa', 'John', 'Teacher', 'TEACHER')
ON DUPLICATE KEY UPDATE username=username;

-- Insert sample student users
INSERT INTO users (username, email, password, first_name, last_name, role) VALUES
('student1', 'student1@codejudge.com', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVEFDa', 'Alice', 'Johnson', 'STUDENT'),
('student2', 'student2@codejudge.com', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVEFDa', 'Bob', 'Smith', 'STUDENT'),
('student3', 'student3@codejudge.com', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVEFDa', 'Charlie', 'Brown', 'STUDENT')
ON DUPLICATE KEY UPDATE username=username;

-- Insert sample problems
INSERT INTO problems (title, description, problem_statement, input_format, output_format, constraints, sample_input, sample_output, explanation, difficulty, time_limit, memory_limit, max_score, created_by) VALUES
(
    'Hello World',
    'Write a program that prints "Hello, World!" to the console.',
    'Your task is to write a simple program that outputs the text "Hello, World!" when executed.',
    'No input is required for this problem.',
    'Output should be exactly: Hello, World!',
    'None',
    'No input',
    'Hello, World!',
    'This is a simple introduction to programming. The program should output the exact text specified.',
    'EASY',
    1000,
    256,
    10,
    1
),
(
    'Sum of Two Numbers',
    'Write a program that reads two integers and prints their sum.',
    'Given two integers a and b, calculate and print their sum.',
    'The first line contains an integer a.\nThe second line contains an integer b.',
    'Print a single integer representing the sum of a and b.',
    '1 ≤ a, b ≤ 1000',
    '5\n3',
    '8',
    'The sum of 5 and 3 is 8.',
    'EASY',
    1000,
    256,
    20,
    1
),
(
    'Factorial',
    'Calculate the factorial of a given number.',
    'Write a program that calculates the factorial of a non-negative integer n. The factorial of n is the product of all positive integers less than or equal to n.',
    'The first line contains an integer n (0 ≤ n ≤ 12).',
    'Print a single integer representing n!',
    '0 ≤ n ≤ 12',
    '5',
    '120',
    '5! = 5 × 4 × 3 × 2 × 1 = 120',
    'MEDIUM',
    1000,
    256,
    30,
    1
),
(
    'Fibonacci Sequence',
    'Generate the first n numbers of the Fibonacci sequence.',
    'The Fibonacci sequence is defined as: F(0) = 0, F(1) = 1, and F(n) = F(n-1) + F(n-2) for n > 1. Write a program that prints the first n Fibonacci numbers.',
    'The first line contains an integer n (1 ≤ n ≤ 20).',
    'Print n space-separated integers representing the first n Fibonacci numbers.',
    '1 ≤ n ≤ 20',
    '8',
    '0 1 1 2 3 5 8 13',
    'The first 8 Fibonacci numbers are: 0, 1, 1, 2, 3, 5, 8, 13',
    'MEDIUM',
    1000,
    256,
    40,
    1
),
(
    'Prime Number Check',
    'Determine if a given number is prime.',
    'A prime number is a natural number greater than 1 that has no positive divisors other than 1 and itself. Write a program that determines if a given number is prime.',
    'The first line contains an integer n (2 ≤ n ≤ 1000).',
    'Print "YES" if n is prime, "NO" otherwise.',
    '2 ≤ n ≤ 1000',
    '17',
    'YES',
    '17 is a prime number because it has no divisors other than 1 and 17.',
    'HARD',
    1000,
    256,
    50,
    1
)
ON DUPLICATE KEY UPDATE title=title;

-- Insert test cases for Hello World
INSERT INTO test_cases (problem_id, input, expected_output, test_case_number, is_sample) VALUES
(1, '', 'Hello, World!', 1, TRUE);

-- Insert test cases for Sum of Two Numbers
INSERT INTO test_cases (problem_id, input, expected_output, test_case_number, is_sample) VALUES
(2, '5\n3', '8', 1, TRUE),
(2, '10\n20', '30', 2, FALSE),
(2, '0\n0', '0', 3, FALSE),
(2, '999\n1', '1000', 4, FALSE);

-- Insert test cases for Factorial
INSERT INTO test_cases (problem_id, input, expected_output, test_case_number, is_sample) VALUES
(3, '5', '120', 1, TRUE),
(3, '0', '1', 2, FALSE),
(3, '1', '1', 3, FALSE),
(3, '10', '3628800', 4, FALSE);

-- Insert test cases for Fibonacci Sequence
INSERT INTO test_cases (problem_id, input, expected_output, test_case_number, is_sample) VALUES
(4, '8', '0 1 1 2 3 5 8 13', 1, TRUE),
(4, '5', '0 1 1 2 3', 2, FALSE),
(4, '1', '0', 3, FALSE),
(4, '10', '0 1 1 2 3 5 8 13 21 34', 4, FALSE);

-- Insert test cases for Prime Number Check
INSERT INTO test_cases (problem_id, input, expected_output, test_case_number, is_sample) VALUES
(5, '17', 'YES', 1, TRUE),
(5, '4', 'NO', 2, FALSE),
(5, '2', 'YES', 3, FALSE),
(5, '100', 'NO', 4, FALSE),
(5, '97', 'YES', 5, FALSE);

-- Create indexes for better performance
CREATE INDEX idx_submissions_user_id ON submissions(user_id);
CREATE INDEX idx_submissions_problem_id ON submissions(problem_id);
CREATE INDEX idx_submissions_status ON submissions(status);
CREATE INDEX idx_test_cases_problem_id ON test_cases(problem_id);
CREATE INDEX idx_test_results_submission_id ON test_results(submission_id);
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_problems_difficulty ON problems(difficulty);
CREATE INDEX idx_problems_created_at ON problems(created_at); 