// Main application JavaScript file
class CodeJudgeApp {
    constructor() {
        this.currentSection = 'home';
        this.currentProblem = null;
        this.apiBaseUrl = 'http://localhost:8080/api';
        this.token = localStorage.getItem('token');
        this.user = JSON.parse(localStorage.getItem('user'));
        
        this.init();
    }
    
    init() {
        this.setupNavigation();
        this.setupMobileMenu();
        this.updateAuthUI();
        this.loadInitialData();
    }
    
    setupNavigation() {
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = link.getAttribute('href').substring(1);
                this.navigateToSection(section);
            });
        });
        
        // Handle browser back/forward
        window.addEventListener('popstate', (e) => {
            if (e.state && e.state.section) {
                this.showSection(e.state.section);
            }
        });
    }
    
    setupMobileMenu() {
        const navToggle = document.getElementById('nav-toggle');
        const navMenu = document.getElementById('nav-menu');
        
        navToggle.addEventListener('click', () => {
            navMenu.classList.toggle('active');
        });
        
        // Close mobile menu when clicking on a link
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('active');
            });
        });
    }
    
    navigateToSection(section) {
        this.showSection(section);
        history.pushState({ section }, '', `#${section}`);
        
        // Update active nav link
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
        });
        document.querySelector(`[href="#${section}"]`)?.classList.add('active');
    }
    
    showSection(section) {
        // Hide all sections
        document.querySelectorAll('.section').forEach(s => {
            s.classList.remove('active');
        });
        
        // Show target section
        const targetSection = document.getElementById(section);
        if (targetSection) {
            targetSection.classList.add('active');
            this.currentSection = section;
            
            // Load section-specific data
            this.loadSectionData(section);
        }
    }
    
    loadSectionData(section) {
        switch (section) {
            case 'problems':
                this.loadProblems();
                break;
            case 'submissions':
                if (this.isAuthenticated()) {
                    this.loadSubmissions();
                } else {
                    this.showToast('Please login to view your submissions', 'warning');
                }
                break;
            case 'leaderboard':
                this.loadLeaderboard();
                break;
        }
    }
    
    loadInitialData() {
        // Load problems for the home page
        if (this.currentSection === 'home') {
            this.loadRecentProblems();
        }
    }
    
    async loadRecentProblems() {
        try {
            const response = await fetch(`${this.apiBaseUrl}/problems/recent?limit=3`);
            const problems = await response.json();
            
            // Display recent problems on home page
            this.displayRecentProblems(problems);
        } catch (error) {
            console.error('Error loading recent problems:', error);
        }
    }
    
    displayRecentProblems(problems) {
        const problemsGrid = document.getElementById('problems-grid');
        if (!problemsGrid) return;
        
        problemsGrid.innerHTML = problems.map(problem => `
            <div class="problem-card" onclick="app.openProblem(${problem.id})">
                <div class="problem-meta">
                    <span class="difficulty-badge ${problem.difficulty.toLowerCase()}">${problem.difficulty}</span>
                    <span>${problem.totalSubmissions} submissions</span>
                </div>
                <h3>${problem.title}</h3>
                <p>${problem.description.substring(0, 100)}...</p>
                <div class="problem-stats">
                    <span><i class="fas fa-check-circle"></i> ${problem.successRate.toFixed(1)}% success rate</span>
                </div>
            </div>
        `).join('');
    }
    
    openProblem(problemId) {
        this.currentProblem = problemId;
        this.navigateToSection('problem-detail');
        this.loadProblemDetail(problemId);
    }
    
    async loadProblemDetail(problemId) {
        try {
            this.showLoading();
            const response = await fetch(`${this.apiBaseUrl}/problems/${problemId}`);
            const problem = await response.json();
            
            this.displayProblemDetail(problem);
            this.initCodeEditor();
        } catch (error) {
            console.error('Error loading problem:', error);
            this.showToast('Error loading problem', 'error');
        } finally {
            this.hideLoading();
        }
    }
    
    displayProblemDetail(problem) {
        document.getElementById('problem-title').textContent = problem.title;
        document.getElementById('problem-difficulty').textContent = problem.difficulty;
        document.getElementById('problem-difficulty').className = `difficulty-badge ${problem.difficulty.toLowerCase()}`;
        document.getElementById('problem-submissions').textContent = problem.totalSubmissions;
        document.getElementById('problem-success-rate').textContent = problem.successRate.toFixed(1);
        document.getElementById('problem-description').innerHTML = problem.description;
        
        // Display examples
        const examplesContainer = document.getElementById('problem-examples');
        if (problem.testCases && problem.testCases.length > 0) {
            const sampleTestCases = problem.testCases.filter(tc => tc.isSample).slice(0, 2);
            examplesContainer.innerHTML = sampleTestCases.map((testCase, index) => `
                <div class="example">
                    <h4>Example ${index + 1}:</h4>
                    <div>
                        <strong>Input:</strong>
                        <pre>${testCase.input}</pre>
                    </div>
                    <div>
                        <strong>Output:</strong>
                        <pre>${testCase.expectedOutput}</pre>
                    </div>
                </div>
            `).join('');
        }
    }
    
    initCodeEditor() {
        const editor = document.getElementById('code-editor');
        if (editor) {
            // Set default Java template
            editor.value = `public class Solution {
    public static void main(String[] args) {
        // Your code here
        System.out.println("Hello, World!");
    }
}`;
        }
    }
    
    async submitCode() {
        if (!this.isAuthenticated()) {
            this.showToast('Please login to submit code', 'warning');
            return;
        }
        
        if (!this.currentProblem) {
            this.showToast('No problem selected', 'error');
            return;
        }
        
        const sourceCode = document.getElementById('code-editor').value;
        const language = document.getElementById('language-select').value;
        
        if (!sourceCode.trim()) {
            this.showToast('Please enter some code', 'warning');
            return;
        }
        
        try {
            this.showLoading();
            const response = await fetch(`${this.apiBaseUrl}/submissions`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.token}`
                },
                body: JSON.stringify({
                    problemId: this.currentProblem,
                    sourceCode: sourceCode,
                    programmingLanguage: language
                })
            });
            
            const result = await response.json();
            
            if (response.ok) {
                this.showToast('Code submitted successfully!', 'success');
                this.pollSubmissionStatus(result.submissionId);
            } else {
                this.showToast(result.error || 'Submission failed', 'error');
            }
        } catch (error) {
            console.error('Error submitting code:', error);
            this.showToast('Error submitting code', 'error');
        } finally {
            this.hideLoading();
        }
    }
    
    async pollSubmissionStatus(submissionId) {
        const maxAttempts = 30; // 30 seconds
        let attempts = 0;
        
        const poll = async () => {
            try {
                const response = await fetch(`${this.apiBaseUrl}/submissions/${submissionId}`);
                const submission = await response.json();
                
                this.displaySubmissionResult(submission);
                
                if (submission.status === 'PENDING' || submission.status === 'COMPILING' || submission.status === 'RUNNING') {
                    if (attempts < maxAttempts) {
                        attempts++;
                        setTimeout(poll, 1000);
                    } else {
                        this.showToast('Submission timeout', 'warning');
                    }
                }
            } catch (error) {
                console.error('Error polling submission:', error);
            }
        };
        
        poll();
    }
    
    displaySubmissionResult(submission) {
        const resultContainer = document.getElementById('submission-result');
        const statusElement = document.getElementById('result-status');
        const detailsElement = document.getElementById('result-details');
        
        resultContainer.style.display = 'block';
        
        // Set status
        statusElement.textContent = submission.status;
        statusElement.className = 'result-status';
        
        if (submission.status === 'ACCEPTED') {
            statusElement.classList.add('accepted');
        } else if (submission.status === 'WRONG_ANSWER') {
            statusElement.classList.add('wrong-answer');
        } else {
            statusElement.classList.add('error');
        }
        
        // Set details
        let details = '';
        if (submission.executionTime) {
            details += `<p><strong>Execution Time:</strong> ${submission.executionTime}ms</p>`;
        }
        if (submission.memoryUsed) {
            details += `<p><strong>Memory Used:</strong> ${submission.memoryUsed}KB</p>`;
        }
        if (submission.score !== null) {
            details += `<p><strong>Score:</strong> ${submission.score}/${submission.problem?.maxScore || 100}</p>`;
        }
        if (submission.passedTestCases !== null && submission.totalTestCases !== null) {
            details += `<p><strong>Test Cases:</strong> ${submission.passedTestCases}/${submission.totalTestCases} passed</p>`;
        }
        if (submission.errorMessage) {
            details += `<p><strong>Error:</strong> ${submission.errorMessage}</p>`;
        }
        
        detailsElement.innerHTML = details;
    }
    
    updateAuthUI() {
        const navAuth = document.getElementById('nav-auth');
        const navUser = document.getElementById('nav-user');
        const userUsername = document.getElementById('user-username');
        
        if (this.isAuthenticated()) {
            navAuth.style.display = 'none';
            navUser.style.display = 'flex';
            userUsername.textContent = this.user?.username || 'User';
        } else {
            navAuth.style.display = 'flex';
            navUser.style.display = 'none';
        }
    }
    
    isAuthenticated() {
        return !!this.token && !!this.user;
    }
    
    showLoading() {
        document.getElementById('loading-spinner').style.display = 'flex';
    }
    
    hideLoading() {
        document.getElementById('loading-spinner').style.display = 'none';
    }
    
    showToast(message, type = 'info') {
        const toastContainer = document.getElementById('toast-container');
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.textContent = message;
        
        toastContainer.appendChild(toast);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            toast.remove();
        }, 5000);
    }
    
    // Navigation helper
    navigateToProblems() {
        this.navigateToSection('problems');
    }
}

// Global app instance
let app;

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    app = new CodeJudgeApp();
});

// Global functions for HTML onclick handlers
function navigateToProblems() {
    app.navigateToProblems();
}

function submitCode() {
    app.submitCode();
}

function showLoginModal() {
    document.getElementById('login-modal').style.display = 'block';
}

function showRegisterModal() {
    document.getElementById('register-modal').style.display = 'block';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

function switchModal(fromModal, toModal) {
    closeModal(fromModal);
    showModal(toModal);
}

function showModal(modalId) {
    document.getElementById(modalId).style.display = 'block';
}

// Close modals when clicking outside
window.addEventListener('click', (e) => {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        if (e.target === modal) {
            modal.style.display = 'none';
        }
    });
}); 