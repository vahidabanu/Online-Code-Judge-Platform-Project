# Online Code Judge Platform API Documentation

## Overview

The Online Code Judge Platform provides a RESTful API for managing coding problems, user submissions, and code execution. This document describes all available endpoints, request/response formats, and authentication requirements.

## Base URL

- **Development**: `http://localhost:8080/api`
- **Production**: `https://your-domain.com/api`

## Authentication

The API uses JWT (JSON Web Tokens) for authentication. Include the token in the Authorization header:

```
Authorization: Bearer <your-jwt-token>
```

## Common Response Formats

### Success Response
```json
{
  "message": "Operation successful",
  "data": { ... }
}
```

### Error Response
```json
{
  "error": "Error message",
  "timestamp": "2024-01-01T12:00:00Z",
  "path": "/api/endpoint"
}
```

## User Management

### Register User
**POST** `/users/register`

Register a new user account.

**Request Body:**
```json
{
  "username": "john_doe",
  "email": "john@example.com",
  "password": "securepassword123",
  "firstName": "John",
  "lastName": "Doe"
}
```

**Response:**
```json
{
  "message": "User registered successfully",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 1,
    "username": "john_doe",
    "email": "john@example.com",
    "firstName": "John",
    "lastName": "Doe",
    "role": "STUDENT"
  }
}
```

### Login User
**POST** `/users/login`

Authenticate user and receive JWT token.

**Request Body:**
```json
{
  "username": "john_doe",
  "password": "securepassword123"
}
```

**Response:**
```json
{
  "message": "Login successful",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 1,
    "username": "john_doe",
    "email": "john@example.com",
    "firstName": "John",
    "lastName": "Doe",
    "role": "STUDENT"
  }
}
```

### Get User Profile
**GET** `/users/profile`

Get current user's profile information.

**Headers:** `Authorization: Bearer <token>`

**Response:**
```json
{
  "id": 1,
  "username": "john_doe",
  "email": "john@example.com",
  "firstName": "John",
  "lastName": "Doe",
  "role": "STUDENT",
  "totalSubmissions": 25,
  "successfulSubmissions": 18,
  "successRate": 72.0,
  "totalScore": 450
}
```

### Update User Profile
**PUT** `/users/profile`

Update current user's profile information.

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "firstName": "John",
  "lastName": "Smith",
  "email": "john.smith@example.com"
}
```

### Get User Statistics
**GET** `/users/stats`

Get current user's submission statistics.

**Headers:** `Authorization: Bearer <token>`

**Response:**
```json
{
  "totalSubmissions": 25,
  "successfulSubmissions": 18,
  "successRate": 72.0,
  "totalScore": 450,
  "problemsSolved": 15,
  "averageScore": 18.0
}
```

### Get Leaderboard
**GET** `/users/leaderboard`

Get global leaderboard.

**Query Parameters:**
- `limit` (optional): Number of users to return (default: 10)
- `offset` (optional): Number of users to skip (default: 0)

**Response:**
```json
[
  {
    "rank": 1,
    "username": "top_coder",
    "totalScore": 1250,
    "problemsSolved": 25,
    "successRate": 85.5
  },
  {
    "rank": 2,
    "username": "john_doe",
    "totalScore": 1100,
    "problemsSolved": 22,
    "successRate": 78.2
  }
]
```

## Problem Management

### Get All Problems
**GET** `/problems`

Get paginated list of problems.

**Query Parameters:**
- `page` (optional): Page number (default: 0)
- `size` (optional): Page size (default: 10)
- `difficulty` (optional): Filter by difficulty (EASY, MEDIUM, HARD, EXPERT)
- `search` (optional): Search in title and description

**Response:**
```json
{
  "content": [
    {
      "id": 1,
      "title": "Hello World",
      "description": "Write a program that prints 'Hello, World!'",
      "difficulty": "EASY",
      "totalSubmissions": 150,
      "successRate": 95.2,
      "maxScore": 10
    }
  ],
  "totalElements": 25,
  "totalPages": 3,
  "currentPage": 0,
  "size": 10
}
```

### Get Problem by ID
**GET** `/problems/{id}`

Get detailed information about a specific problem.

**Response:**
```json
{
  "id": 1,
  "title": "Hello World",
  "description": "Write a program that prints 'Hello, World!' to the console.",
  "problemStatement": "Your task is to write a simple program...",
  "inputFormat": "No input is required for this problem.",
  "outputFormat": "Output should be exactly: Hello, World!",
  "constraints": "None",
  "sampleInput": "No input",
  "sampleOutput": "Hello, World!",
  "explanation": "This is a simple introduction to programming...",
  "difficulty": "EASY",
  "timeLimit": 1000,
  "memoryLimit": 256,
  "maxScore": 10,
  "totalSubmissions": 150,
  "successRate": 95.2,
  "testCases": [
    {
      "id": 1,
      "input": "",
      "expectedOutput": "Hello, World!",
      "isSample": true
    }
  ]
}
```

### Create Problem (Admin/Teacher Only)
**POST** `/problems`

Create a new coding problem.

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "title": "New Problem",
  "description": "Problem description",
  "problemStatement": "Detailed problem statement",
  "inputFormat": "Input format description",
  "outputFormat": "Output format description",
  "constraints": "Problem constraints",
  "sampleInput": "Sample input",
  "sampleOutput": "Sample output",
  "explanation": "Solution explanation",
  "difficulty": "MEDIUM",
  "timeLimit": 2000,
  "memoryLimit": 512,
  "maxScore": 50,
  "testCases": [
    {
      "input": "test input",
      "expectedOutput": "expected output",
      "isSample": true,
      "isHidden": false
    }
  ]
}
```

### Update Problem (Admin/Teacher Only)
**PUT** `/problems/{id}`

Update an existing problem.

**Headers:** `Authorization: Bearer <token>`

**Request Body:** Same as Create Problem

### Delete Problem (Admin Only)
**DELETE** `/problems/{id}`

Delete a problem.

**Headers:** `Authorization: Bearer <token>`

### Get Problem Statistics
**GET** `/problems/{id}/stats`

Get statistics for a specific problem.

**Response:**
```json
{
  "totalSubmissions": 150,
  "successfulSubmissions": 143,
  "successRate": 95.2,
  "averageScore": 9.5,
  "averageExecutionTime": 45,
  "averageMemoryUsed": 128,
  "difficultyDistribution": {
    "easy": 80,
    "medium": 45,
    "hard": 20,
    "expert": 5
  }
}
```

### Search Problems
**GET** `/problems/search`

Search problems by title or description.

**Query Parameters:**
- `query`: Search query
- `page` (optional): Page number
- `size` (optional): Page size

### Get Recent Problems
**GET** `/problems/recent`

Get recently added problems.

**Query Parameters:**
- `limit` (optional): Number of problems to return (default: 5)

### Get Popular Problems
**GET** `/problems/popular`

Get most submitted problems.

**Query Parameters:**
- `limit` (optional): Number of problems to return (default: 10)

## Submissions

### Submit Code
**POST** `/submissions`

Submit code for a problem.

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "problemId": 1,
  "sourceCode": "public class Solution {\n    public static void main(String[] args) {\n        System.out.println(\"Hello, World!\");\n    }\n}",
  "programmingLanguage": "JAVA"
}
```

**Response:**
```json
{
  "message": "Submission received and queued for execution",
  "submissionId": 123,
  "status": "PENDING"
}
```

### Get Submission
**GET** `/submissions/{id}`

Get submission details and results.

**Response:**
```json
{
  "id": 123,
  "problemId": 1,
  "problemTitle": "Hello World",
  "sourceCode": "public class Solution {...}",
  "programmingLanguage": "JAVA",
  "status": "ACCEPTED",
  "executionTime": 45,
  "memoryUsed": 128,
  "score": 10,
  "totalTestCases": 1,
  "passedTestCases": 1,
  "errorMessage": null,
  "submittedAt": "2024-01-01T12:00:00Z",
  "evaluatedAt": "2024-01-01T12:00:05Z",
  "testResults": [
    {
      "testCaseId": 1,
      "status": "PASSED",
      "actualOutput": "Hello, World!",
      "expectedOutput": "Hello, World!",
      "executionTime": 45,
      "isCorrect": true
    }
  ]
}
```

### Get User Submissions
**GET** `/submissions/user`

Get current user's submissions.

**Headers:** `Authorization: Bearer <token>`

**Query Parameters:**
- `page` (optional): Page number
- `size` (optional): Page size

### Get Problem Submissions
**GET** `/submissions/problem/{problemId}`

Get all submissions for a specific problem.

**Query Parameters:**
- `page` (optional): Page number
- `size` (optional): Page size

### Get All Submissions (Admin/Teacher Only)
**GET** `/submissions`

Get all submissions in the system.

**Headers:** `Authorization: Bearer <token>`

**Query Parameters:**
- `page` (optional): Page number
- `size` (optional): Page size
- `status` (optional): Filter by status
- `language` (optional): Filter by programming language

### Get Submission Statistics
**GET** `/submissions/stats`

Get current user's submission statistics.

**Headers:** `Authorization: Bearer <token>`

**Response:**
```json
{
  "totalSubmissions": 25,
  "acceptedSubmissions": 18,
  "wrongAnswerSubmissions": 5,
  "compilationErrorSubmissions": 2,
  "successRate": 72.0,
  "averageExecutionTime": 45,
  "averageMemoryUsed": 128,
  "languagesUsed": {
    "JAVA": 15,
    "PYTHON": 8,
    "CPP": 2
  }
}
```

### Get Recent Submissions
**GET** `/submissions/recent`

Get recent submissions across all users.

**Query Parameters:**
- `limit` (optional): Number of submissions to return (default: 10)

### Re-run Submission (Admin/Teacher Only)
**POST** `/submissions/{id}/rerun`

Re-execute a submission.

**Headers:** `Authorization: Bearer <token>`

### Get Submission Test Results
**GET** `/submissions/{id}/test-results`

Get detailed test results for a submission.

### Get User's Best Submission
**GET** `/submissions/user/{userId}/problem/{problemId}/best`

Get user's best submission for a specific problem.

## Error Codes

| Code | Description |
|------|-------------|
| 400 | Bad Request - Invalid input data |
| 401 | Unauthorized - Authentication required |
| 403 | Forbidden - Insufficient permissions |
| 404 | Not Found - Resource not found |
| 409 | Conflict - Resource already exists |
| 422 | Unprocessable Entity - Validation error |
| 500 | Internal Server Error - Server error |

## Rate Limiting

The API implements rate limiting to prevent abuse:

- **Authenticated users**: 100 requests per minute
- **Unauthenticated users**: 20 requests per minute

Rate limit headers are included in responses:
- `X-RateLimit-Limit`: Request limit per window
- `X-RateLimit-Remaining`: Remaining requests in current window
- `X-RateLimit-Reset`: Time when the rate limit resets

## Pagination

List endpoints support pagination with the following query parameters:

- `page`: Page number (0-based, default: 0)
- `size`: Page size (default: 10, max: 100)

Response includes pagination metadata:
```json
{
  "content": [...],
  "totalElements": 100,
  "totalPages": 10,
  "currentPage": 0,
  "size": 10,
  "first": true,
  "last": false
}
```

## WebSocket Endpoints

### Real-time Submission Updates
**WebSocket** `/ws/submissions/{submissionId}`

Subscribe to real-time updates for a specific submission.

**Message Format:**
```json
{
  "type": "SUBMISSION_UPDATE",
  "submissionId": 123,
  "status": "RUNNING",
  "progress": 50,
  "message": "Executing test case 2 of 4"
}
```

## Health Check

### Application Health
**GET** `/actuator/health`

Check application health status.

**Response:**
```json
{
  "status": "UP",
  "components": {
    "db": {
      "status": "UP",
      "details": {
        "database": "MySQL",
        "validationQuery": "isValid()"
      }
    },
    "diskSpace": {
      "status": "UP",
      "details": {
        "total": 499963174912,
        "free": 419430400000,
        "threshold": 10485760
      }
    }
  }
}
``` 