# Online Code Judge Platform - Manual Setup Guide

## Prerequisites Installation

### 1. Install Java 17
1. Download OpenJDK 17 from: https://adoptium.net/
2. Run the installer
3. Set JAVA_HOME environment variable
4. Verify installation:
   ```bash
   java --version
   ```

### 2. Install Maven
1. Download Maven from: https://maven.apache.org/download.cgi
2. Extract to a directory (e.g., `C:\Program Files\Apache\maven`)
3. Add Maven to PATH environment variable
4. Verify installation:
   ```bash
   mvn --version
   ```

### 3. Install MySQL 8.0
1. Download MySQL Community Server from: https://dev.mysql.com/downloads/mysql/
2. Run the installer
3. Set root password: `codejudge123`
4. Create database and user:
   ```sql
   CREATE DATABASE codejudge;
   CREATE USER 'codejudge'@'localhost' IDENTIFIED BY 'codejudge123';
   GRANT ALL PRIVILEGES ON codejudge.* TO 'codejudge'@'localhost';
   FLUSH PRIVILEGES;
   ```

### 4. Install Node.js (Optional - for frontend development)
1. Download Node.js from: https://nodejs.org/
2. Run the installer
3. Verify installation:
   ```bash
   node --version
   npm --version
   ```

## Manual Setup Steps

### Step 1: Database Setup
1. Open MySQL Command Line Client or MySQL Workbench
2. Run the database initialization script:
   ```bash
   mysql -u root -p < database/init.sql
   ```

### Step 2: Backend Setup
1. Navigate to the backend directory:
   ```bash
   cd backend
   ```

2. Build the project:
   ```bash
   mvn clean install
   ```

3. Run the application:
   ```bash
   mvn spring-boot:run
   ```

The backend will start on `http://localhost:8080`

### Step 3: Frontend Setup (Optional)
1. Navigate to the frontend directory:
   ```bash
   cd frontend
   ```

2. Install dependencies (if using Node.js):
   ```bash
   npm install
   ```

3. Serve the frontend using a local server:
   ```bash
   # Using Python (if available)
   python -m http.server 3000
   
   # Or using Node.js
   npx http-server -p 3000
   
   # Or simply open index.html in a browser
   ```

## Configuration

### Backend Configuration
The backend is configured to connect to MySQL on localhost. If you need to change the database connection, edit `backend/src/main/resources/application.yml`:

```yaml
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/codejudge?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC
    username: codejudge
    password: codejudge123
```

### Frontend Configuration
The frontend is configured to connect to the backend API at `http://localhost:8080`. If you change the backend URL, update `frontend/static/js/app.js`:

```javascript
this.apiBaseUrl = 'http://localhost:8080/api';
```

## Testing the Setup

### 1. Backend Health Check
Visit: `http://localhost:8080/actuator/health`

Expected response:
```json
{
  "status": "UP"
}
```

### 2. API Test
Visit: `http://localhost:8080/api/problems`

Expected response: List of problems (may be empty initially)

### 3. Frontend Test
Visit: `http://localhost:3000` (or open `frontend/index.html` in browser)

## Troubleshooting

### Common Issues

#### 1. Java Version Issues
```bash
# Check Java version
java --version

# Should show Java 17 or higher
```

#### 2. Maven Issues
```bash
# Check Maven version
mvn --version

# Clean and rebuild
mvn clean install
```

#### 3. Database Connection Issues
- Verify MySQL is running
- Check database credentials in `application.yml`
- Ensure database and user exist

#### 4. Port Conflicts
- Backend uses port 8080
- Frontend uses port 3000
- MySQL uses port 3306

If ports are in use, change them in the configuration files.

### Sample Data
The database initialization script includes sample data:
- Admin user: `admin` / `password123`
- Teacher user: `teacher` / `password123`
- Student users: `student1`, `student2`, `student3` / `password123`
- Sample problems: Hello World, Sum of Two Numbers, Factorial, etc.

## Development Workflow

### Backend Development
1. Make changes to Java files
2. Restart the application: `mvn spring-boot:run`
3. Or use Spring Boot DevTools for auto-restart

### Frontend Development
1. Make changes to HTML/CSS/JS files
2. Refresh the browser
3. Or use a live reload server

### Database Changes
1. Make changes to entities
2. Update database schema manually or let JPA handle it
3. Restart the application

## Production Deployment

For production deployment, consider:
1. Using a proper web server (Apache, Nginx)
2. Setting up SSL certificates
3. Configuring proper database credentials
4. Setting up monitoring and logging
5. Using Docker for consistency

## Support

If you encounter issues:
1. Check the logs in the console
2. Verify all prerequisites are installed correctly
3. Ensure all services are running
4. Check network connectivity and firewall settings 