# Online Code Judge Platform

A comprehensive coding platform that allows students to register, solve coding problems, and compete on leaderboards with automated code execution and evaluation.

## 🚀 Features

- **User Management**: Registration, authentication, and profile management
- **Problem Management**: Create and manage coding problems with test cases
- **Code Execution Engine**: Safe sandboxed execution for Java code
- **Real-time Results**: Immediate feedback on code submissions
- **Leaderboards**: Performance ranking and competition tracking
- **Docker Integration**: Isolated execution environments
- **CI/CD Pipeline**: Automated deployment with GitHub Actions
- **AWS Deployment**: Cloud-hosted platform

## 🛠 Tech Stack

- **Backend**: Java (Spring Boot)
- **Frontend**: HTML, CSS, JavaScript
- **Database**: MySQL
- **Containerization**: Docker
- **Cloud**: AWS EC2
- **CI/CD**: GitHub Actions
- **Project Management**: Trello (Agile methodology)

## 📁 Project Structure

```
├── backend/                 # Java Spring Boot application
│   ├── src/main/java/      # Java source code
│   ├── src/main/resources/ # Configuration files
│   └── Dockerfile          # Backend containerization
├── frontend/               # Web interface
│   ├── static/            # HTML, CSS, JS files
│   └── templates/         # Server-side templates
├── docker/                # Docker configuration
│   ├── docker-compose.yml # Multi-container setup
│   └── nginx/             # Reverse proxy configuration
├── database/              # Database scripts and migrations
├── scripts/               # Deployment and utility scripts
├── tests/                 # Test suites
└── docs/                  # Documentation

```

## 🚀 Quick Start

### Prerequisites
- Java 17+
- Maven 3.6+
- Docker & Docker Compose
- MySQL 8.0+
- Node.js 16+ (for frontend build)

### Local Development Setup

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd online-code-judge-platform
   ```

2. **Start with Docker Compose**
   ```bash
   docker-compose up -d
   ```

3. **Access the application**
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:8080
   - Database: localhost:3306

### Manual Setup

1. **Database Setup**
   ```bash
   mysql -u root -p < database/init.sql
   ```

2. **Backend Setup**
   ```bash
   cd backend
   mvn clean install
   mvn spring-boot:run
   ```

3. **Frontend Setup**
   ```bash
   cd frontend
   npm install
   npm start
   ```

## 🧪 Testing

```bash
# Run all tests
mvn test

# Run specific test suites
mvn test -Dtest=CodeExecutionTest
mvn test -Dtest=UserServiceTest
```

## 🚀 Deployment

### AWS EC2 Deployment

1. **Provision EC2 Instance**
   ```bash
   # Use the provided AWS CloudFormation template
   aws cloudformation create-stack --stack-name code-judge-platform --template-body file://aws/cloudformation.yml
   ```

2. **Deploy with CI/CD**
   - Push to main branch triggers automatic deployment
   - GitHub Actions handles build, test, and deployment

### Manual Deployment

```bash
# Build and deploy
./scripts/deploy.sh
```

## 📊 Architecture

### Code Execution Engine
- **Sandboxing**: Docker containers for isolated execution
- **Security**: Resource limits and network isolation
- **Scalability**: Horizontal scaling with load balancing

### Database Schema
- **Users**: Authentication and profile data
- **Problems**: Problem definitions and test cases
- **Submissions**: Code submissions and results
- **Leaderboards**: Performance rankings and statistics

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Follow the coding standards
4. Add tests for new features
5. Submit a pull request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

For support and questions:
- Create an issue in the repository
- Check the documentation in `/docs`
- Review the troubleshooting guide

## 📈 Roadmap

- [ ] Support for additional programming languages (Python, C++, JavaScript)
- [ ] Real-time collaborative coding
- [ ] Advanced analytics and insights
- [ ] Mobile application
- [ ] Integration with learning management systems 