#!/bin/bash

# Online Code Judge Platform Deployment Script
# This script deploys the application to AWS EC2

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
APP_NAME="codejudge"
DOCKER_COMPOSE_FILE="docker-compose.yml"
BACKUP_DIR="/home/ubuntu/backups"
LOG_DIR="/home/ubuntu/logs"

# Functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
if [[ $EUID -eq 0 ]]; then
   log_error "This script should not be run as root"
   exit 1
fi

# Create necessary directories
log_info "Creating necessary directories..."
mkdir -p $BACKUP_DIR
mkdir -p $LOG_DIR

# Backup current deployment
if [ -f "$DOCKER_COMPOSE_FILE" ]; then
    log_info "Creating backup of current deployment..."
    BACKUP_FILE="$BACKUP_DIR/backup-$(date +%Y%m%d-%H%M%S).tar.gz"
    tar -czf "$BACKUP_FILE" --exclude='./logs' --exclude='./backups' .
    log_success "Backup created: $BACKUP_FILE"
fi

# Stop current services
log_info "Stopping current services..."
if docker-compose ps | grep -q "Up"; then
    docker-compose down
    log_success "Services stopped"
else
    log_warning "No running services found"
fi

# Pull latest images
log_info "Pulling latest Docker images..."
docker-compose pull
log_success "Images pulled successfully"

# Start services
log_info "Starting services..."
docker-compose up -d
log_success "Services started"

# Wait for services to be ready
log_info "Waiting for services to be ready..."
sleep 30

# Check service health
log_info "Checking service health..."
if docker-compose ps | grep -q "Up"; then
    log_success "All services are running"
else
    log_error "Some services failed to start"
    docker-compose logs
    exit 1
fi

# Health checks
log_info "Performing health checks..."

# Check backend health
if curl -f http://localhost:8080/actuator/health > /dev/null 2>&1; then
    log_success "Backend health check passed"
else
    log_error "Backend health check failed"
    exit 1
fi

# Check frontend health
if curl -f http://localhost:3000/health > /dev/null 2>&1; then
    log_success "Frontend health check passed"
else
    log_error "Frontend health check failed"
    exit 1
fi

# Check database connection
if docker-compose exec -T mysql mysqladmin ping -h localhost --silent; then
    log_success "Database health check passed"
else
    log_error "Database health check failed"
    exit 1
fi

# Clean up old images
log_info "Cleaning up old Docker images..."
docker image prune -f
log_success "Cleanup completed"

# Show service status
log_info "Service status:"
docker-compose ps

# Show resource usage
log_info "Resource usage:"
docker stats --no-stream

log_success "Deployment completed successfully!"
log_info "Application is available at:"
echo "  - Frontend: http://$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4):3000"
echo "  - Backend API: http://$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4):8080"
echo "  - Health Check: http://$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4):8080/actuator/health"

# Optional: Send notification
if [ -n "$SLACK_WEBHOOK" ]; then
    log_info "Sending deployment notification..."
    curl -X POST -H 'Content-type: application/json' \
        --data "{\"text\":\"✅ CodeJudge Platform deployed successfully!\"}" \
        "$SLACK_WEBHOOK"
fi 